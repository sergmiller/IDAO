export PATH=/usr/conda/bin:$PATH
python -c "print('hi from python start')"
python -c "import torchvision.models as models; resnet18 = models.resnet18(pretrained=True)"
python -c "print('hi from python end')"
